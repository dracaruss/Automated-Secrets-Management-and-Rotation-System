import boto3
import json
import os
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)


# Cache the secret to avoid calling Secrets Manager on every invocation.
# Lambda containers are reused, so this persists across warm invocations.
# The secret is refreshed when the container is recycled (cold start).
_cached_secret = None


def get_db_credentials():
    """
    Retrieve database credentials from Secrets Manager.
    Uses caching to minimize API calls and reduce latency.
    
    Returns:
        dict with keys: username, password, host, port, dbname, engine
    """
    global _cached_secret
    
    if _cached_secret is not None:
        logger.info('Using cached credentials')
        return _cached_secret
    
    secret_id = os.environ['SECRET_ARN']
    client = boto3.client('secretsmanager')
    
    response = client.get_secret_value(SecretId=secret_id)
    _cached_secret = json.loads(response['SecretString'])
    
    logger.info(f'Retrieved fresh credentials for user: {_cached_secret["username"]}')
    # NEVER log the actual password
    
    return _cached_secret




def lambda_handler(event, context):
    """
    Sample application handler that uses database credentials.
    In a real app, this would connect to the database.
    """
    creds = get_db_credentials()
    
    # Demonstrate we have the credentials (without exposing the password)
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Successfully retrieved database credentials',
            'username': creds['username'],
            'host': creds['host'],
            'port': creds['port'],
            'dbname': creds['dbname'],
            'password_length': len(creds['password']),
            'password_retrieved': True
            # NEVER include the actual password in a response
        })
    }
